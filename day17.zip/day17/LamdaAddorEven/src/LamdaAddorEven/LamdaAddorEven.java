package LamdaAddorEven;

import java.util.Scanner;

interface check
{
	public void checked(int a);
}


public class LamdaAddorEven {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("which number you want to check: ");
		int num =  input.nextInt();
		
		check che = (int a) -> {
			int b;
			b = a%2;
			if (b == 0) {
				System.out.println("This is even number");
			}
			else {
				System.out.println("This is add number");
			}
		};
		
		che.checked(num);
	}

}
