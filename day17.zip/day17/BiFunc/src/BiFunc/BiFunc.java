package BiFunc;

import java.util.function.BiFunction;  

class add1 {
	public static int addIn1(int a, int b) {
		return a+b;
	}
	
	public static String addIn2(String a, String b) {
		return a+b;
	}
}

interface sub1 {
	public static int subIn1(int a, int b) {
		return a-b;
	}
	
	public static String subIn2 (String a, String b) {
		return b=a;
	}
	
	public static Float subIn3 (Float a, Float b) {
		return a-b;
	}
	
}
public class BiFunc {

	public static void main(String[] args) {
		
		BiFunction<Integer, Integer, Integer> addedFunc1 = add1::addIn1;
		int result1 = addedFunc1.apply(10, 12);
		System.out.println(result1);
		
		
		BiFunction<String, String, String> addedFunc2 = add1::addIn2;
		String result2 = addedFunc2.apply("Bi", "Function");
		System.out.println(result2);
		
		BiFunction<Integer, Integer, Integer> subFunc1 = sub1::subIn1;
		int result3 = subFunc1.apply(100, 10);
		System.out.println(result3);
		
		BiFunction<String, String, String > subFunc2 = sub1::subIn2;
		String result4 = subFunc2.apply("lamda", "BiFunction");
		System.out.println(result4);
		
		BiFunction<Float, Float, Float > subFunc3 = sub1::subIn3;
		Float result5 = subFunc3.apply(12f, 16f);
		System.out.println(result5);
	}
}
