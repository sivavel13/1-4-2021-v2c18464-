package LengthStr;

import java.util.Scanner;

class normal{
	
	public void normalway() {
		Scanner input1 = new Scanner(System.in);
		System.out.println("Find the string length is normal way");
		System.out.println("Enter the string1 : ");		
		String str1 = input1.nextLine();		
		System.out.println("The string length is : " + str1.length());
	}	
}

interface lamda{
	public void lamdaway();
}

public class LengthStr {

	public static void main(String[] args) {	
		normal n1 = new normal();
		n1.normalway();	

		lamda l1 = () -> {
			Scanner input2 = new Scanner(System.in);
			System.out.println("Find the string length is Lamda way");
			System.out.println("Enter the string2 : ");		
			String str2 = input2.nextLine();		
			System.out.println("The string length is : " + str2.length());
			};
			
		l1.lamdaway();
		
		
		}

}

